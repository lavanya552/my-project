from django.shortcuts import render
from student.models import *

from hod.models import *
from examination.models import *
# Create your views here.

def hod_active(request): 
    print request.user
    temp_dep=Faculty.objects.filter(username=request.user)[0]
    temp_hod=HOD.objects.filter(status="",department=temp_dep.department)
    if request.method=='POST':
        temp_id=request.POST['id']
        hod=HOD.objects.filter(id_number=temp_id)[0]
        hod.status="yes"
        hod.remarks="nothing"
        hod.save()
        temp=Examination()
        temp.id_number=hod.id_number
        temp.department=hod.department
        temp.certificate_type=hod.certificate_type
        temp.status=""
        temp.remarks=""
        temp.save()

    return render(request,'hod/active.html',{'hod':temp_hod})

def hod_approved(request): 
    print request.user
    temp_hod=HOD.objects.filter(status="yes")
    return render(request,'hod/approved.html',{'hod':temp_hod})

