from django.contrib import admin

# Register your models here.

from hod.models import *


admin.site.register(HOD)
