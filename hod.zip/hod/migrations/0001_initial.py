# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'HOD'
        db.create_table(u'hod_hod', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('id_number', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('department', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('status', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('remarks', self.gf('django.db.models.fields.TextField')()),
            ('certificate_type', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'hod', ['HOD'])


    def backwards(self, orm):
        # Deleting model 'HOD'
        db.delete_table(u'hod_hod')


    models = {
        u'hod.hod': {
            'Meta': {'object_name': 'HOD'},
            'certificate_type': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'department': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'id_number': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'remarks': ('django.db.models.fields.TextField', [], {}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        }
    }

    complete_apps = ['hod']