from django.conf.urls import patterns, include, url

from hod import views

urlpatterns = patterns('',
    url(r'^$', views.hod_active, name='hod_active'),
    url(r'^active/$', views.hod_active, name='hod_active'),
    url(r'^approved/$', views.hod_approved, name='hod_approved'),
)
