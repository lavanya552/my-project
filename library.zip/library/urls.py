from django.conf.urls import patterns, include, url

from library import views

urlpatterns = patterns('',
    url(r'^$', views.library_active, name='library_active'),
    url(r'^active/$', views.library_active, name='library_active'),
    url(r'^pending/$', views.library_pending, name='library_pending'),
    url(r'^approved/$', views.library_approved, name='library_approved'),
)
