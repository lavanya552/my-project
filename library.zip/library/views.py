from django.shortcuts import render
from student.models import *

from hod.models import *
from examination.models import *
from library.models import *
from pt.models import *

# Create your views here.

def library_active(request): 
    print request.user
    temp_lib=Library.objects.filter(status="")
    if request.method=='POST':
        temp_id=request.POST['id']
        temp_remarks=request.POST['remarks']
        temp_status=request.POST['status']
#        temp_id=request.user
        lib=Library.objects.filter(id_number=temp_id)[0]
        lib.status=temp_status
        lib.remarks=temp_remarks
        lib.save()
        if temp_status == "yes":
            pt=PT()
            pt.id_number=lib.id_number
            pt.department=lib.department
            pt.certificate_type=lib.certificate_type
            pt.status=""
            pt.remarks=""
            pt.save()

    return render(request,'library/active.html',{'lib':temp_lib,'department':"library"})

def library_pending(request): 
    print request.user
    temp_lib=Library.objects.filter(status="no")
    if request.method=='POST':
        temp_id=request.POST['id']
        temp_remarks=request.POST['remarks']
        temp_status=request.POST['status']
#        temp_id=request.user
        lib=Library.objects.filter(id_number=temp_id)[0]
        lib.status=temp_status
        lib.remarks=temp_remarks
        lib.save()
        if temp_status == "yes":
            pt=PT()
            pt.id_number=lib.id_number
            pt.department=lib.department
            pt.certificate_type=lib.certificate_type
            pt.status=""
            pt.remarks=""
            pt.save()

    return render(request,'library/pending.html',{'lib':temp_lib,'department':"library"})


def library_approved(request): 
    print request.user
    temp_lib=Library.objects.filter(status="yes")
    return render(request,'library/approved.html',{'lib':temp_lib,'department':"library"})



