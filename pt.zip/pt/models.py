from django.db import models

# Create your models here.

class PT(models.Model):
        id_number=models.CharField(max_length=255)
	department=models.CharField(max_length=255)
	status=models.CharField(max_length = 255)
	remarks=models.TextField()
	pt_fine=models.CharField(max_length = 255)
	certificate_type=models.CharField(max_length = 255)
	def __str__(self):
		return self.id_number +","+ self.department

