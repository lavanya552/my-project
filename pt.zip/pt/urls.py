from django.conf.urls import patterns, include, url

from pt import views

urlpatterns = patterns('',
    url(r'^$', views.pt_active, name='pt_active'),
    url(r'^active/$', views.pt_active, name='pt_active'),
    url(r'^pending/$', views.pt_pending, name='pt_pending'),
    url(r'^approved/$', views.pt_approved, name='pt_approved'),
)
