from django.shortcuts import render
from student.models import *

from hod.models import *
from examination.models import *
from pt.models import *
from director.models import *

# Create your views here.

def pt_active(request): 
    print request.user
    temp_pt=PT.objects.filter(status="")
    if request.method=='POST':
        temp_id=request.POST['id']
        temp_remarks=request.POST['remarks']
        temp_status=request.POST['status']
#        temp_id=request.user
        pt=PT.objects.filter(id_number=temp_id)[0]
        pt.status=temp_status
        pt.remarks=temp_remarks
        pt.save()
        if temp_status == "yes":
            director=Director()
            director.id_number=pt.id_number
            director.department=pt.department
            director.certificate_type=pt.certificate_type
            director.status=""
            director.remarks=""
            director.save()

    return render(request,'pt/active.html',{'pt':temp_pt,'department':"pt"})

def pt_pending(request): 
    print request.user
    temp_pt=PT.objects.filter(status="no")
    if request.method=='POST':
        temp_id=request.POST['id']
        temp_remarks=request.POST['remarks']
        temp_status=request.POST['status']
#        temp_id=request.user
        pt=PT.objects.filter(id_number=temp_id)[0]
        pt.status=temp_status
        pt.remarks=temp_remarks
        pt.save()
        if temp_status == "yes":
            director=Director()
            director.id_number=pt.id_number
            director.department=pt.department
            director.certificate_type=pt.certificate_type
            director.status=""
            director.remarks=""
            director.save()

    return render(request,'pt/pending.html',{'pt':temp_pt,'department':"pt"})


def pt_approved(request): 
    print request.user
    temp_pt=PT.objects.filter(status="yes")
    return render(request,'pt/approved.html',{'pt':temp_pt,'department':"pt"})


