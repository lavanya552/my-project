from django.contrib import admin

# Register your models here.

from pt.models import *


admin.site.register(PT)

