# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'PT'
        db.create_table(u'pt_pt', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('id_number', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('department', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('status', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('remarks', self.gf('django.db.models.fields.TextField')()),
            ('pt_fine', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('certificate_type', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'pt', ['PT'])


    def backwards(self, orm):
        # Deleting model 'PT'
        db.delete_table(u'pt_pt')


    models = {
        u'pt.pt': {
            'Meta': {'object_name': 'PT'},
            'certificate_type': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'department': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'id_number': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'pt_fine': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'remarks': ('django.db.models.fields.TextField', [], {}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        }
    }

    complete_apps = ['pt']