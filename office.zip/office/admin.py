from django.contrib import admin

from office.models import *


admin.site.register(Office)
admin.site.register(Office_final)
admin.site.register(File)
