from django.conf.urls import patterns, include, url

from office import views

urlpatterns = patterns('',
    url(r'^$', views.office_active, name='office_active'),
    url(r'^active/$', views.office_active, name='office_active'),
    url(r'^pending/$', views.office_pending, name='office_pending'),
    url(r'^approved/$', views.office_approved, name='office_approved'),
    url(r'^approved_issue/$', views.office_issue_approved, name='office_approved_issue'),
    url(r'^ack1/$', views.office_ack_1, name='office_acknowledgement1'),
    url(r'^(?P<student_id>[^/]+)/issue/$', views.office_issue_id, name='office_issue_certificate'),
    url(r'^all_issue/$', views.office_issue, name='office_issue_all'),
)
