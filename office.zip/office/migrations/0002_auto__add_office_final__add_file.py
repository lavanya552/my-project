# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'Office_final'
        db.create_table(u'office_office_final', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('id_number', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('department', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('final_status', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('remarks', self.gf('django.db.models.fields.TextField')()),
            ('certificate_type', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('pc', self.gf('django.db.models.fields.related.ForeignKey')(related_name='pc', to=orm['office.File'])),
            ('marks_memos', self.gf('django.db.models.fields.related.ForeignKey')(related_name='marks_memo', to=orm['office.File'])),
            ('study', self.gf('django.db.models.fields.related.ForeignKey')(related_name='study', to=orm['office.File'])),
        ))
        db.send_create_signal(u'office', ['Office_final'])

        # Adding model 'File'
        db.create_table(u'office_file', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('path', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal(u'office', ['File'])


    def backwards(self, orm):
        # Deleting model 'Office_final'
        db.delete_table(u'office_office_final')

        # Deleting model 'File'
        db.delete_table(u'office_file')


    models = {
        u'office.file': {
            'Meta': {'object_name': 'File'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'path': ('django.db.models.fields.TextField', [], {})
        },
        u'office.office': {
            'Meta': {'object_name': 'Office'},
            'certificate_type': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'department': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'id_number': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'remarks': ('django.db.models.fields.TextField', [], {}),
            'status': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'office.office_final': {
            'Meta': {'object_name': 'Office_final'},
            'certificate_type': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'department': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'final_status': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'id_number': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'marks_memos': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'marks_memo'", 'to': u"orm['office.File']"}),
            'pc': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'pc'", 'to': u"orm['office.File']"}),
            'remarks': ('django.db.models.fields.TextField', [], {}),
            'study': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'study'", 'to': u"orm['office.File']"})
        }
    }

    complete_apps = ['office']