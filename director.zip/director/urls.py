from django.conf.urls import patterns, include, url

from director import views

urlpatterns = patterns('',
    url(r'^$', views.director_active, name='director_active'),
    url(r'^active/$', views.director_active, name='director_active'),
    url(r'^approved/$', views.director_approved, name='director_approved'),
)
