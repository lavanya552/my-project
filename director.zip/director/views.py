from django.shortcuts import render
from student.models import *
from office.models import *
from office.views import *
from hod.models import *
from director.models import *
# Create your views here.

def director_active(request): 
    print request.user
#    temp_dep=Faculty.objects.filter(username=request.user)[0]
    temp_director=Director.objects.filter(status="")
    if request.method=='POST':
        temp_id=request.POST['id']
        director=Director.objects.filter(id_number=temp_id)[0]
        director.status="yes"
        director.remarks="nothing"
        director.save()
        office_final=Office_final()
        office_final.id_number = request.POST['id']
        office_final.department = director.department
        office_final.certificate_type = director.certificate_type
        office_final.final_status = ""
        office_final.pc =new_file("")
        office_final.marks_memos = new_file("")
        office_final.study = new_file("")
        office_final.save()

    return render(request,'director/active.html',{'director':temp_director,'department':"director"})

def director_approved(request): 
    print request.user
    temp_director=Director.objects.filter(status="yes")
    return render(request,'director/approved.html',{'director':temp_director,'department':"director"})

