from django.shortcuts import render,redirect
from student.models import *
from hod.models import *
from examination.models import *
from library.models import *
from pt.models import *
from director.models import *
from office.models import *

from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.core.context_processors import csrf

from django.views.static import serve
import os

def logout_view(request, redirect_url = "/"): # Logout Page View
    if request.user.is_authenticated():
        logout(request) 
        request.session.flush() # clears the session and details of logged in users
        request.user = None
#messages.add_message(request,messages.SUCCESS, "Successfully Logged Out !") # message displayed after logout
        return redirect(redirect_url)

def login_view(request): # login page view
    # checking another user is logged in or not
    if request.user != None: 
        if request.user.is_authenticated():
            return logout_view(request, "/")
    c = {}
    c.update(csrf(request)) # csrf token is issue to the  logged user
    return render(request,'student/login.html', c)

#Login Verification and Redirects to Home Page
def authorize(request):
     temp_username = request.POST['username']
     temp_password = request.POST['password']
     account_type = request.POST['account']
     print account_type
     print temp_username
     print temp_password

     user = authenticate(username = temp_username, password = temp_password) #Checks the database for Valid username and password
     print user
     if user != None: 
	#user.backend = 'rgukt.auth_backends.PortalUserModelBackend'
          if user.is_active:
                     login(request, user)
                     messages.add_message(request,messages.SUCCESS, "Successfully Logged In !")# Message displayed after login
                     if account_type == "student":
                         return redirect("/student/home")
                     else:
			# print "in staff "
                         # Admin is logged in then it redirects Admin Home Page 
                         staff_temp=Faculty.objects.filter(username=temp_username)[0]
                         all_departments=["CSE","ECE","CIVIL","MECH","MME","CHEM"]
                         if staff_temp.department in all_departments:
                             return redirect("/hod/")
                         else:
                             return redirect("/"+staff_temp.department+"")
                     return redirect("/")#Student Redirect to Home Page
          else: 
                     messages.add_message(request,messages.WARNING, "User Inactive")
                     return redirect("/")
     else:
         messages.add_message(request,messages.ERROR, "Authentication Failed, Login again.")
         return redirect("/")

def student_home(request):
    print request.user
    office=Office.objects.filter(id_number=request.user)
    office_final=Office_final.objects.filter(id_number=request.user)
    if office:
        office =office[0]
    if office_final:
        office_final=office_final[0]
    if request.method=='POST':
        temp_certificate=request.POST['certificate']
        temp_id=request.user
        student=Student.objects.filter(id_number=temp_id)[0]
        temp_department=student.department
        office=Office()
        office.id_number=temp_id
        office.department=temp_department
        office.status=""
        office.remarks=""
        office.certificate_type=temp_certificate
        office.save()

        return redirect('/student/status/')
    return render(request,'student/home.html',{'office':office,'office_final':office_final,'Final':office_final})

def student_status(request): 
	student=Student.objects.filter(id_number=request.user)[0]
	office=Office.objects.filter(id_number=request.user)
	hod=HOD.objects.filter(id_number=request.user)
	examination=Examination.objects.filter(id_number=request.user)
	library=Library.objects.filter(id_number=request.user)
	pt=PT.objects.filter(id_number=request.user)
	director=Director.objects.filter(id_number=request.user)
	office_final=Office_final.objects.filter(id_number=request.user)
        dict_temp={"office":office,"hod":hod,"examination":examination,"library":library,"pt":pt,"director":director}
        temp_stage=""
        temp_remarks=""
        list_all=[office,hod,examination,library,pt,director]
        for temp in list_all:
            if temp: 
                temp=temp[0]
        for k,v in dict_temp.iteritems(): 
            if v :
                v=v[0]
                if v.status == "":
                    temp_stage=k
                    temp_remarks=""
                if v.status == "no":
                    temp_stage=k
                    temp_remarks=v.remarks
        if office_final:
            office_final=office_final[0]
            if office_final.final_status == "":
                temp_stage= "Office Final Stage"
                temp_remarks=" "
            if office_final.final_status == "no":
                temp_stage=" Office Final Stage"
                temp_remarks=office_final.remarks
            if office_final.final_status == "yes":
                temp_stage="Certificate request process is completed"
                temp_remarks=""
        print temp_stage
        print temp_remarks

	return render(request,'student/status.html', {'student':student,'office':office,'stage':temp_stage,'remarks':temp_remarks,'office':office,'hod':hod,'examination':examination,'library':library,'pt':pt,'director':director,'Final':office_final})

def student_details(request): 
	student=Student.objects.filter(id_number=request.user)[0]
	office_final=Office_final.objects.filter(id_number=request.user)
        if office_final:
            office_final = office_final[0]

        print student
	return render(request,'student/details.html', {'student':student,'Final':office_final})

def student_certificates(request): 
	student=Student.objects.filter(id_number=request.user)[0]
	office=Office_final.objects.filter(id_number=request.user)
        if office:
            office=office[0] 
        if request.method == 'POST':
            temp_certificate=request.POST['type']
            if temp_certificate == "pc":    
                filepath = office.pc.path
                return serve(request, os.path.basename(filepath), os.path.dirname(filepath))
            if temp_certificate == "marks_memos":     
                filepath = office.marks_memos.path
                return serve(request, os.path.basename(filepath), os.path.dirname(filepath))
            if temp_certificate == "study":     
                filepath = office.study.path
                return serve(request, os.path.basename(filepath), os.path.dirname(filepath))

	return render(request,'student/certificates.html', {'student':student,'office':office,'Final':office})


