from django.core.management.base import BaseCommand, CommandError #Imoprting BaseCommand
from django.contrib.auth.models import User
from django.db import models
import os,inspect
from PCA.settings import * 
import sys
import csv,datetime
from student.models import *


# Color For  Command 
class Color(object):
    UNDERLINE = '\033[4m'
    END = '\033[0m'
    BOLD = '\033[1m'
    GRAY = '\033[1;30m'
    RED = '\033[1;31m'
    GREEN = '\033[1;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[1;34m'
    MAGENTA = '\033[1;35m'
    CYAN = '\033[1;36m'
    WHITE = '\033[1;37m'
    CRIMSON = '\033[1;38m'

    @staticmethod
    def pad(string, bold = False):
        if bold:
            return Color.UNDERLINE + Color.BOLD + string + Color.END

        return Color.UNDERLINE + string + Color.END
    @staticmethod
    def cpad(string, color):
        return color + string + Color.END

# Command Processing
class Command(BaseCommand):
    args = ""
    help = "Creates a SuperUser"
    

    def p(self, string): # Display Content
        self.stdout.write(string)
    
    def ep(self, string, times = 0):# Display Content with Color RED
        self.p(" "*times + "-> " + Color.pad(Color.cpad(string, Color.RED)))

    def sp(self, string, times = 0): # Display Content with Color Green
        self.p(" "*times + "-> " + Color.pad(Color.cpad(string, Color.GREEN)))

#handling createsuperuser 
    def handle(self, *args, **options):
        with open(os.path.join(BASE_DIR, 'student1.csv')) as f:
            delimiter = ","
            for index,row in enumerate(f.readlines()):
            	if index > 0:
            		row = row.strip("\n\t ").split(delimiter)
	            	student=Student()
	            	student.name=row[1]
	            	student.id_number=row[0]
	            	student.password=row[2]
        	    	student.sex=row[4]
        	    	student.father_name=row[3]
        	    	student.department=row[14]
        	    	student.date_of_birth=datetime.datetime(2015, 5, 2)
        	    	student.email_id=row[5]
        	    	student.phone=row[6]
        	    	student.ssc_marks=row[7]
        	    	student.inter_marks=row[8]
        	    	student.btech_marks=row[9]
        	    	student.scholarship_details=row[10]
        	    	student.back_logs=row[11]
        	    	student.achievements=row[12]
        	    	student.save()
        with open(os.path.join(BASE_DIR, 'faculty1.csv')) as f:
            delimiter = ","
            for index,row in enumerate(f.readlines()):
            	if index > 0:
            		row = row.strip("\n\t ").split(delimiter)
	            	faculty=Faculty()
	            	faculty.name=row[0]
	            	faculty.username=row[1]
	            	faculty.password=row[2]
        	    	faculty.department=row[3]
        	    	faculty.qualification=row[4]
        	    	faculty.publication_papers=row[5]
        	    	faculty.certificates=row[6]
        	    	faculty.save()
        students=Student.objects.all()
        for stu in students:
		user = User.objects.create_user(stu.id_number, stu.email_id, stu.password)	

        facultys=Faculty.objects.all()
        for fact in facultys:
		user = User.objects.create_user(fact.username,"temp@gmail.com", fact.password)
                user.is_staff="t"
                user.save()	

