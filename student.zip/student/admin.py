from django.contrib import admin

from student.models import *

class StudentAdmin(admin.ModelAdmin):
	list_display = ('id_number','name','department')
	list_filter = ['department']


admin.site.register(Student,StudentAdmin)
admin.site.register(Faculty)

