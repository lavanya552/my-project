from django.conf.urls import patterns, include, url

from student import views

urlpatterns = patterns('',
     url(r'^home/$', views.student_home, name='student_home'),
     url(r'^status/$', views.student_status, name='student_status'),
     url(r'^authenticate/$', views.authorize, name='student_authenticate'),
     url(r'^details/$', views.student_details, name='student_details'),
     url(r'^certificates/$', views.student_certificates, name='student_certificates'),
)
