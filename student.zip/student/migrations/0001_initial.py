# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'Student'
        db.create_table(u'student_student', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('id_number', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('password', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('sex', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('father_name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('date_of_birth', self.gf('django.db.models.fields.DateField')()),
            ('department', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('email_id', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('phone', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('ssc_marks', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('inter_marks', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('btech_marks', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('scholarship_details', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('back_logs', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('achievements', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'student', ['Student'])

        # Adding model 'Faculty'
        db.create_table(u'student_faculty', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('username', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('password', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('department', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('qualification', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('publication_papers', self.gf('django.db.models.fields.TextField')()),
            ('certificates', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'student', ['Faculty'])


    def backwards(self, orm):
        # Deleting model 'Student'
        db.delete_table(u'student_student')

        # Deleting model 'Faculty'
        db.delete_table(u'student_faculty')


    models = {
        u'student.faculty': {
            'Meta': {'object_name': 'Faculty'},
            'certificates': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'department': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'publication_papers': ('django.db.models.fields.TextField', [], {}),
            'qualification': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'username': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'student.student': {
            'Meta': {'object_name': 'Student'},
            'achievements': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'back_logs': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'btech_marks': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'date_of_birth': ('django.db.models.fields.DateField', [], {}),
            'department': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'email_id': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'id_number': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'inter_marks': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'scholarship_details': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'sex': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'ssc_marks': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        }
    }

    complete_apps = ['student']