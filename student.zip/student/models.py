from django.db import models

# Create your models here.

class Student(models.Model):
	name=models.CharField(max_length=255)
        id_number=models.CharField(max_length=255)
        password=models.CharField(max_length=255)
        sex=models.CharField(max_length=255)
	father_name=models.CharField(max_length=255)
        date_of_birth=models.DateField('date of birth')
	department=models.CharField(max_length=255)
	email_id=models.CharField(max_length=255)
	phone = models.CharField(max_length = 255)
	ssc_marks = models.CharField(max_length = 255)
	inter_marks=models.CharField(max_length = 255)
	btech_marks=models.CharField(max_length = 255)
	scholarship_details=models.CharField(max_length = 255)
	back_logs=models.CharField(max_length = 255)
	achievements=models.CharField(max_length = 255)
	def __str__(self):
		return self.name +","+ self.id_number
	
class Faculty(models.Model):
	name=models.CharField(max_length=255)
        username=models.CharField(max_length=255)
        password=models.CharField(max_length=255)
	department=models.CharField(max_length=255)
	qualification=models.CharField(max_length=255)
	publication_papers = models.TextField()
	certificates = models.CharField(max_length = 255)
	def __str__(self):
		return self.name

