from django.shortcuts import render
from student.models import *

from hod.models import *
from examination.models import *
from library.models import *

# Create your views here.

def examination_active(request): 
    print request.user
    temp_exam=Examination.objects.filter(status="")
    if request.method=='POST':
        temp_id=request.POST['id']
        temp_remarks=request.POST['remarks']
        temp_status=request.POST['status']
#        temp_id=request.user
        exam=Examination.objects.filter(id_number=temp_id)[0]
        exam.status=temp_status
        exam.remarks=temp_remarks
        exam.save()
        if temp_status == "yes":
            lib=Library()
            lib.id_number=exam.id_number
            lib.department=exam.department
            lib.certificate_type=exam.certificate_type
            lib.status=""
            lib.remarks=""
            lib.save()

    return render(request,'examination/active.html',{'exam':temp_exam,'department':"examination"})

def examination_pending(request): 
    print request.user
    temp_exam=Examination.objects.filter(status="no")
    if request.method=='POST':
        temp_id=request.POST['id']
        temp_remarks=request.POST['remarks']
        temp_status=request.POST['status']
#        temp_id=request.user
        exam=Examination.objects.filter(id_number=temp_id)[0]
        exam.status=temp_status
        exam.remarks=temp_remarks
        exam.save()
        if temp_status == "yes":
            lib=Library()
            lib.id_number=exam.id_number
            lib.department=exam.department
            lib.certificate_type=exam.certificate_type
            lib.status=""
            lib.remarks=""
            lib.save()

    return render(request,'examination/pending.html',{'exam':temp_exam,'department':"examination"})


def examination_approved(request): 
    print request.user
    temp_exam=Examination.objects.filter(status="yes")
    return render(request,'examination/approved.html',{'exam':temp_exam,'department':"examination"})



