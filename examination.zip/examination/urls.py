from django.conf.urls import patterns, include, url

from examination import views

urlpatterns = patterns('',
    url(r'^$', views.examination_active, name='examination_active'),
    url(r'^active/$', views.examination_active, name='examination_active'),
    url(r'^pending/$', views.examination_pending, name='examination_pending'),
    url(r'^approved/$', views.examination_approved, name='examination_approved'),
)
